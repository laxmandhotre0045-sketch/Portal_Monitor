package portalmonitor;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;

/** Builds the DOWN / RECOVERED email subject, HTML and plain text. */
public final class EmailTemplates {

    public record Email(String subject, String html, String text) { }

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private EmailTemplates() { }

    public static Email down(Portal p, CheckResult r, LocalDateTime failSince, LocalDateTime now, int failCount) {
        Map<String, String> rows = new LinkedHashMap<>();
        rows.put("Portal", p.name());
        rows.put("Health URL", p.healthUrl());
        rows.put("Result", r.httpCode() == 0 ? "No response" : "HTTP " + r.httpCode());
        rows.put("Error", r.error() == null ? "-" : r.error());
        rows.put("Failing since", FMT.format(failSince));
        rows.put("Consecutive failures", String.valueOf(failCount));
        rows.put("Detected at", FMT.format(now));
        return build("\uD83D\uDD34 DOWN: " + p.name(), p.name() + " is DOWN", "#c0392b", rows);
    }

    public static Email recovered(Portal p, CheckResult r, LocalDateTime failSince, LocalDateTime now) {
        Map<String, String> rows = new LinkedHashMap<>();
        rows.put("Portal", p.name());
        rows.put("Health URL", p.healthUrl());
        rows.put("Result", "HTTP " + r.httpCode());
        rows.put("Response time", r.responseMs() + " ms");
        rows.put("Was down from", FMT.format(failSince));
        rows.put("Recovered at", FMT.format(now));
        rows.put("Total downtime", humanDuration(Duration.between(failSince, now)));
        return build("\uD83D\uDFE2 RECOVERED: " + p.name(), p.name() + " is back UP", "#27ae60", rows);
    }

    static String humanDuration(Duration d) {
        long s = Math.max(0, d.getSeconds());
        long days = s / 86400; s %= 86400;
        long h = s / 3600;     s %= 3600;
        long m = s / 60;       s %= 60;
        StringBuilder sb = new StringBuilder();
        if (days > 0) sb.append(days).append("d ");
        if (h > 0) sb.append(h).append("h ");
        if (m > 0) sb.append(m).append("m ");
        if (sb.length() == 0 || (days == 0 && h == 0)) sb.append(s).append("s");
        return sb.toString().trim();
    }

    private static Email build(String subject, String title, String color, Map<String, String> rows) {
        StringBuilder htmlRows = new StringBuilder();
        StringBuilder text = new StringBuilder(title).append("\n\n");
        rows.forEach((k, v) -> {
            htmlRows.append("<tr><td style=\"padding:6px 12px;color:#555;border-bottom:1px solid #eee\"><b>")
                    .append(esc(k)).append("</b></td><td style=\"padding:6px 12px;border-bottom:1px solid #eee\">")
                    .append(esc(v)).append("</td></tr>");
            text.append(String.format("%-22s%s%n", k + ":", v));
        });
        String html = "<div style=\"font-family:Arial,sans-serif;max-width:600px\">"
                + "<div style=\"background:" + color + ";color:#fff;padding:14px 16px;font-size:18px;font-weight:bold\">"
                + esc(title) + "</div>"
                + "<table style=\"border-collapse:collapse;width:100%;font-size:14px\">" + htmlRows + "</table>"
                + "<p style=\"color:#888;font-size:12px;margin-top:12px\">Automated alert from Portal Monitor.</p></div>";
        return new Email(subject, html, text.toString());
    }

    private static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#39;");
    }
}
