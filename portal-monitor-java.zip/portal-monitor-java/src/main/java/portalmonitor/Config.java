package portalmonitor;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Properties;
import java.util.Set;
import java.util.stream.Collectors;

/** Reads application.properties into typed settings. */
public final class Config {

    public final String dbUrl, dbUser, dbPassword;
    public final String smtpHost, smtpSecurity, smtpUser, smtpPassword, smtpFrom, smtpFromName;
    public final int smtpPort;
    public final String defaultEmail;
    public final int intervalSeconds, failThreshold, connectTimeoutSeconds, requestTimeoutSeconds;
    public final Set<Integer> successCodes;
    public final boolean verifySsl;
    public final int logRetentionDays;
    public final ZoneId zone;

    private Config(Properties p) {
        dbUrl        = req(p, "db.url");
        dbUser       = req(p, "db.user");
        dbPassword   = p.getProperty("db.password", "");

        smtpHost     = req(p, "smtp.host");
        smtpPort     = Integer.parseInt(p.getProperty("smtp.port", "465").trim());
        smtpSecurity = p.getProperty("smtp.security", "ssl").trim().toLowerCase();
        smtpUser     = p.getProperty("smtp.user", "").trim();
        smtpPassword = p.getProperty("smtp.password", "");
        smtpFrom     = req(p, "smtp.from");
        smtpFromName = p.getProperty("smtp.fromName", "Portal Monitor").trim();

        defaultEmail          = p.getProperty("alert.defaultEmail", "").trim();
        intervalSeconds       = Integer.parseInt(p.getProperty("check.intervalSeconds", "60").trim());
        failThreshold         = Integer.parseInt(p.getProperty("check.failThreshold", "3").trim());
        connectTimeoutSeconds = Integer.parseInt(p.getProperty("check.connectTimeoutSeconds", "5").trim());
        requestTimeoutSeconds = Integer.parseInt(p.getProperty("check.requestTimeoutSeconds", "10").trim());
        successCodes = Arrays.stream(p.getProperty("check.successCodes", "200").split(","))
                .map(String::trim).filter(s -> !s.isEmpty()).map(Integer::valueOf)
                .collect(Collectors.toUnmodifiableSet());
        verifySsl        = Boolean.parseBoolean(p.getProperty("check.verifySsl", "true").trim());
        logRetentionDays = Integer.parseInt(p.getProperty("log.retentionDays", "30").trim());
        zone             = ZoneId.of(p.getProperty("app.timezone", "Asia/Kolkata").trim());
    }

    public static Config load(Path file) throws IOException {
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(file)) {
            p.load(in);
        }
        return new Config(p);
    }

    private static String req(Properties p, String key) {
        String v = p.getProperty(key);
        if (v == null || v.isBlank()) {
            throw new IllegalArgumentException("Missing required setting: " + key);
        }
        return v.trim();
    }
}
