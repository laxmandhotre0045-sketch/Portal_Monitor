package portalmonitor;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

/** All SQL lives here. A fresh connection is opened per check cycle (survives DB restarts). */
public final class Database implements AutoCloseable {

    private final Connection conn;

    public Database(Config cfg) throws SQLException {
        conn = DriverManager.getConnection(cfg.dbUrl, cfg.dbUser, cfg.dbPassword);
        // Keep MySQL NOW() in the same time zone as the app
        String offset = ZonedDateTime.now(cfg.zone).getOffset().getId();
        if ("Z".equals(offset)) offset = "+00:00";
        try (Statement st = conn.createStatement()) {
            st.execute("SET time_zone = '" + offset + "'");
        }
    }

    public List<Portal> activePortals() throws SQLException {
        String sql = "SELECT id, portal_name, notify_email, health_url, status, fail_count, fail_since, last_status_change "
                   + "FROM portals WHERE is_active = 1 ORDER BY id";
        List<Portal> list = new ArrayList<>();
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                list.add(new Portal(
                        rs.getInt("id"),
                        rs.getString("portal_name"),
                        rs.getString("notify_email"),
                        rs.getString("health_url"),
                        rs.getString("status"),
                        rs.getInt("fail_count"),
                        toLdt(rs.getTimestamp("fail_since")),
                        toLdt(rs.getTimestamp("last_status_change"))));
            }
        }
        return list;
    }

    public void insertCheckLog(int portalId, CheckResult r, LocalDateTime at) throws SQLException {
        String sql = "INSERT INTO check_logs (portal_id, http_code, response_ms, is_up, error, checked_at) VALUES (?,?,?,?,?,?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, portalId);
            ps.setInt(2, r.httpCode());
            ps.setLong(3, r.responseMs());
            ps.setInt(4, r.up() ? 1 : 0);
            ps.setString(5, r.error());
            ps.setTimestamp(6, Timestamp.valueOf(at));
            ps.executeUpdate();
        }
    }

    public void updatePortal(int id, String status, int failCount, LocalDateTime failSince, CheckResult r,
                             LocalDateTime checkedAt, LocalDateTime statusChange) throws SQLException {
        String sql = "UPDATE portals SET status=?, fail_count=?, fail_since=?, last_http_code=?, last_response_ms=?, "
                   + "last_error=?, last_checked=?, last_status_change=? WHERE id=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, failCount);
            ps.setTimestamp(3, failSince == null ? null : Timestamp.valueOf(failSince));
            ps.setInt(4, r.httpCode());
            ps.setLong(5, r.responseMs());
            ps.setString(6, r.error());
            ps.setTimestamp(7, Timestamp.valueOf(checkedAt));
            ps.setTimestamp(8, statusChange == null ? null : Timestamp.valueOf(statusChange));
            ps.setInt(9, id);
            ps.executeUpdate();
        }
    }

    public void insertAlertLog(int portalId, String type, String sentTo, boolean ok, String error, LocalDateTime at)
            throws SQLException {
        String sql = "INSERT INTO alert_logs (portal_id, alert_type, sent_to, success, error, sent_at) VALUES (?,?,?,?,?,?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, portalId);
            ps.setString(2, type);
            ps.setString(3, sentTo);
            ps.setInt(4, ok ? 1 : 0);
            ps.setString(5, error == null ? null : truncate(error, 490));
            ps.setTimestamp(6, Timestamp.valueOf(at));
            ps.executeUpdate();
        }
    }

    public int deleteOldLogs(int retentionDays) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(
                "DELETE FROM check_logs WHERE checked_at < NOW() - INTERVAL ? DAY")) {
            ps.setInt(1, retentionDays);
            return ps.executeUpdate();
        }
    }

    private static LocalDateTime toLdt(Timestamp t) {
        return t == null ? null : t.toLocalDateTime();
    }

    static String truncate(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max);
    }

    @Override
    public void close() throws SQLException {
        conn.close();
    }
}
