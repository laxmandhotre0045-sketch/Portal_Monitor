package portalmonitor;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * One check cycle:
 *  - check every active portal in parallel
 *  - log each result
 *  - UP -> DOWN after N consecutive failures  => DOWN email (once)
 *  - DOWN -> UP                               => RECOVERED email with downtime
 */
public final class MonitorService {

    private final Config cfg;
    private final HealthChecker checker;
    private final EmailService mailer;

    public MonitorService(Config cfg) {
        this.cfg = cfg;
        this.checker = new HealthChecker(cfg);
        this.mailer = new EmailService(cfg);
    }

    public void runOnce() {
        try (Database db = new Database(cfg)) {
            List<Portal> portals = db.activePortals();
            if (portals.isEmpty()) {
                Log.info("No active portals in the database.");
                return;
            }

            Map<Integer, CheckResult> results = checker.checkAll(portals);
            LocalDateTime now = LocalDateTime.now(cfg.zone).withNano(0);

            for (Portal p : portals) {
                try {
                    process(db, p, results.get(p.id()), now);
                } catch (Exception e) {
                    Log.error("Failed to process " + p.name() + ": " + e.getMessage());
                }
            }

            int deleted = db.deleteOldLogs(cfg.logRetentionDays);
            if (deleted > 0) Log.info("Deleted " + deleted + " old check_logs rows.");
            Log.info("Done. Checked " + portals.size() + " portal(s).");
        } catch (Exception e) {
            Log.error("Check cycle failed: " + e.getMessage());
        }
    }

    private void process(Database db, Portal p, CheckResult r, LocalDateTime now) throws Exception {
        db.insertCheckLog(p.id(), r, now);

        String newStatus = p.status();
        LocalDateTime statusChange = p.lastStatusChange();
        int failCount;
        LocalDateTime failSince;

        if (r.up()) {
            // Healthy: clear the failure streak; email only if it WAS down
            if ("DOWN".equals(p.status())) {
                LocalDateTime since = p.failSince() != null ? p.failSince() : now;
                sendAlert(db, p, "RECOVERED", EmailTemplates.recovered(p, r, since, now), now);
            }
            if (!"UP".equals(p.status())) {
                newStatus = "UP";
                statusChange = now;
            }
            failCount = 0;
            failSince = null;
        } else {
            // Unhealthy: count consecutive failures; email once when the threshold is reached
            failCount = p.failCount() + 1;
            failSince = p.failSince() != null ? p.failSince() : now;
            if (!"DOWN".equals(p.status()) && failCount >= cfg.failThreshold) {
                newStatus = "DOWN";
                statusChange = now;
                sendAlert(db, p, "DOWN", EmailTemplates.down(p, r, failSince, now, failCount), now);
            }
        }

        db.updatePortal(p.id(), newStatus, failCount, failSince, r, now, statusChange);

        Log.info(String.format("%-25s %-7s code=%-3d %5dms fails=%d%s",
                p.name(), newStatus, r.httpCode(), r.responseMs(), failCount,
                r.error() != null ? "  (" + r.error() + ")" : ""));
    }

    private void sendAlert(Database db, Portal p, String type, EmailTemplates.Email email, LocalDateTime now)
            throws Exception {
        String to = p.notifyEmail() != null && !p.notifyEmail().isBlank() ? p.notifyEmail() : cfg.defaultEmail;
        EmailService.SendResult res = mailer.send(to, email.subject(), email.html(), email.text());
        db.insertAlertLog(p.id(), type, to, res.ok(), res.error(), now);
        Log.info("  -> " + type + " email to " + to + ": " + (res.ok() ? "sent" : "FAILED (" + res.error() + ")"));
    }

    /** Sends a single test email (used by --test-email). */
    public boolean sendTestEmail(String to) {
        EmailService.SendResult r = mailer.send(to, "Portal Monitor - test email",
                "<p>SMTP is working. Alerts from Portal Monitor will arrive like this.</p>",
                "SMTP is working. Alerts from Portal Monitor will arrive like this.");
        Log.info(r.ok() ? "Test email sent to " + to : "Test email FAILED: " + r.error());
        return r.ok();
    }
}
