package portalmonitor;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** Minimal timestamped console logging (captured by systemd / journalctl). */
final class Log {
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private Log() { }

    static void info(String msg)  { System.out.println("[" + FMT.format(LocalDateTime.now()) + "] " + msg); }
    static void error(String msg) { System.err.println("[" + FMT.format(LocalDateTime.now()) + "] ERROR " + msg); }
}
