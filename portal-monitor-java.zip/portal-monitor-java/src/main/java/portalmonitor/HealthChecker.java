package portalmonitor;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.net.ConnectException;
import java.net.URI;
import java.net.UnknownHostException;
import java.net.http.HttpClient;
import java.net.http.HttpConnectTimeoutException;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;

/** Calls every portal's health URL in parallel and reports the HTTP code / error. */
public final class HealthChecker {

    private final Config cfg;
    private final HttpClient client;

    public HealthChecker(Config cfg) {
        this.cfg = cfg;
        HttpClient.Builder b = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(cfg.connectTimeoutSeconds))
                .followRedirects(HttpClient.Redirect.NEVER);
        if (!cfg.verifySsl) {
            // Accept self-signed certificates (only when explicitly configured)
            System.setProperty("jdk.internal.httpclient.disableHostnameVerification", "true");
            b.sslContext(trustAllContext());
        }
        this.client = b.build();
    }

    public Map<Integer, CheckResult> checkAll(List<Portal> portals) {
        Map<Integer, CompletableFuture<CheckResult>> futures = new HashMap<>();
        for (Portal p : portals) {
            futures.put(p.id(), checkOne(p.healthUrl()));
        }
        Map<Integer, CheckResult> results = new HashMap<>();
        futures.forEach((id, f) -> results.put(id, f.join()));
        return results;
    }

    private CompletableFuture<CheckResult> checkOne(String url) {
        long start = System.nanoTime();
        HttpRequest req;
        try {
            req = HttpRequest.newBuilder(URI.create(url.trim()))
                    .timeout(Duration.ofSeconds(cfg.requestTimeoutSeconds))
                    .header("User-Agent", "PortalMonitor/1.0")
                    .header("Accept", "application/json, text/plain, */*")
                    .GET().build();
        } catch (IllegalArgumentException e) {
            return CompletableFuture.completedFuture(new CheckResult(0, 0, "Invalid URL: " + e.getMessage(), false));
        }

        return client.sendAsync(req, HttpResponse.BodyHandlers.discarding())
                .handle((resp, ex) -> {
                    long ms = (System.nanoTime() - start) / 1_000_000;
                    if (ex == null) {
                        int code = resp.statusCode();
                        boolean up = cfg.successCodes.contains(code);
                        return new CheckResult(code, ms, up ? null : "HTTP " + code, up);
                    }
                    return new CheckResult(0, ms, describe(ex), false);
                });
    }

    private static String describe(Throwable ex) {
        Throwable t = ex instanceof CompletionException && ex.getCause() != null ? ex.getCause() : ex;
        // walk to the root cause for clearer messages
        Throwable root = t;
        while (root.getCause() != null && root.getCause() != root) root = root.getCause();

        String msg;
        if (t instanceof HttpConnectTimeoutException) msg = "Connection timed out";
        else if (t instanceof HttpTimeoutException) msg = "Timeout - no response in time";
        else if (root instanceof UnknownHostException || root instanceof java.nio.channels.UnresolvedAddressException) msg = "Unknown host (DNS failed)";
        else if (t instanceof ConnectException || root instanceof ConnectException) msg = "Couldn't connect to server";
        else if (root instanceof javax.net.ssl.SSLException) msg = "SSL error: " + root.getMessage();
        else msg = root.getClass().getSimpleName() + (root.getMessage() != null ? ": " + root.getMessage() : "");
        return Database.truncate(msg, 250);
    }

    private static SSLContext trustAllContext() {
        try {
            TrustManager[] trustAll = {new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] c, String a) { }
                public void checkServerTrusted(X509Certificate[] c, String a) { }
                public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
            }};
            SSLContext ctx = SSLContext.getInstance("TLS");
            ctx.init(null, trustAll, new java.security.SecureRandom());
            return ctx;
        } catch (Exception e) {
            throw new IllegalStateException("Could not create SSL context", e);
        }
    }
}
