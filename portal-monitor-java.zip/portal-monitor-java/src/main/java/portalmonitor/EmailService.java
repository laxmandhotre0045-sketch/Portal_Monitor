package portalmonitor;

import jakarta.mail.*;
import jakarta.mail.internet.*;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;

/** Sends HTML + plain-text emails through SMTP (Hostinger: smtp.hostinger.com:465 SSL). */
public final class EmailService {

    /** Result of a send attempt. */
    public record SendResult(boolean ok, String error) { }

    private final Config cfg;
    private final Session session;

    public EmailService(Config cfg) {
        this.cfg = cfg;
        Properties p = new Properties();
        p.put("mail.smtp.host", cfg.smtpHost);
        p.put("mail.smtp.port", String.valueOf(cfg.smtpPort));
        p.put("mail.smtp.connectiontimeout", "20000");
        p.put("mail.smtp.timeout", "20000");
        p.put("mail.smtp.writetimeout", "20000");
        boolean auth = !cfg.smtpUser.isEmpty();
        p.put("mail.smtp.auth", String.valueOf(auth));
        switch (cfg.smtpSecurity) {
            case "ssl" -> p.put("mail.smtp.ssl.enable", "true");
            case "tls" -> { p.put("mail.smtp.starttls.enable", "true"); p.put("mail.smtp.starttls.required", "true"); }
            default -> { /* "none": plain SMTP, for local testing only */ }
        }
        Authenticator a = auth ? new Authenticator() {
            @Override protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(cfg.smtpUser, cfg.smtpPassword);
            }
        } : null;
        this.session = Session.getInstance(p, a);
    }

    /** "a@x.com, b@y.com; c@z.com" -> valid, de-duplicated addresses. */
    public static List<String> parseEmails(String list) {
        if (list == null) return List.of();
        Set<String> out = new LinkedHashSet<>();
        for (String s : Arrays.asList(list.split("[\\s,;]+"))) {
            if (s.isBlank()) continue;
            try {
                InternetAddress ia = new InternetAddress(s, true);
                ia.validate();
                out.add(ia.getAddress());
            } catch (AddressException ignored) {
                // skip invalid address
            }
        }
        return List.copyOf(out);
    }

    public SendResult send(String recipients, String subject, String html, String text) {
        List<String> to = parseEmails(recipients);
        if (to.isEmpty()) {
            return new SendResult(false, "No valid email address in: " + recipients);
        }
        try {
            MimeMessage msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress(cfg.smtpFrom, cfg.smtpFromName, "UTF-8"));
            for (String addr : to) {
                msg.addRecipient(Message.RecipientType.TO, new InternetAddress(addr));
            }
            msg.setSubject(subject, "UTF-8");

            MimeBodyPart textPart = new MimeBodyPart();
            textPart.setText(text, "UTF-8");
            MimeBodyPart htmlPart = new MimeBodyPart();
            htmlPart.setContent(html, "text/html; charset=UTF-8");
            MimeMultipart body = new MimeMultipart("alternative");
            body.addBodyPart(textPart);   // fallback first
            body.addBodyPart(htmlPart);   // preferred last
            msg.setContent(body);

            Transport.send(msg);
            return new SendResult(true, null);
        } catch (Exception e) {
            String m = e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName();
            return new SendResult(false, m.replaceAll("\\s+", " ").trim());
        }
    }
}
