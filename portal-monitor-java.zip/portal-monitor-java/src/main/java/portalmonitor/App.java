package portalmonitor;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.TimeZone;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Usage:
 *   java -jar portal-monitor.jar                           run forever, check every check.intervalSeconds
 *   java -jar portal-monitor.jar --once                    run one check cycle and exit (for cron)
 *   java -jar portal-monitor.jar --test-email you@x.com    send one test email and exit
 *   add  --config /path/application.properties             (default: ./application.properties)
 */
public final class App {

    public static void main(String[] args) throws Exception {
        Path configPath = Path.of("application.properties");
        boolean once = false;
        String testEmailTo = null;

        for (int i = 0; i < args.length; i++) {
            switch (args[i]) {
                case "--once" -> once = true;
                case "--config" -> configPath = Path.of(args[++i]);
                case "--test-email" -> testEmailTo = args[++i];
                default -> { System.err.println("Unknown argument: " + args[i]); System.exit(2); }
            }
        }

        if (!Files.exists(configPath)) {
            System.err.println("Config file not found: " + configPath.toAbsolutePath());
            System.exit(1);
        }
        Config cfg = Config.load(configPath);
        TimeZone.setDefault(TimeZone.getTimeZone(cfg.zone));
        MonitorService monitor = new MonitorService(cfg);

        if (testEmailTo != null) {
            System.exit(monitor.sendTestEmail(testEmailTo) ? 0 : 1);
        }
        if (once) {
            monitor.runOnce();
            return;
        }

        Log.info("Portal Monitor started. Checking every " + cfg.intervalSeconds + "s.");
        ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
        // fixed DELAY: the next cycle starts only after the previous one finishes (never overlaps)
        scheduler.scheduleWithFixedDelay(() -> {
            try {
                monitor.runOnce();
            } catch (Throwable t) {
                Log.error("Unexpected error: " + t);
            }
        }, 0, cfg.intervalSeconds, TimeUnit.SECONDS);

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            Log.info("Shutting down.");
            scheduler.shutdownNow();
        }));
    }
}
