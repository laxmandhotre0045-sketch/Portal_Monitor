package portalmonitor;

import java.time.LocalDateTime;

/** One row of the portals table. */
public record Portal(
        int id,
        String name,
        String notifyEmail,
        String healthUrl,
        String status,          // UNKNOWN / UP / DOWN
        int failCount,
        LocalDateTime failSince,
        LocalDateTime lastStatusChange) {
}
