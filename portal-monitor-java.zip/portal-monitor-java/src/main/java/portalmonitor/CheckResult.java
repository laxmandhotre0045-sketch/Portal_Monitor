package portalmonitor;

/** Outcome of one health check. httpCode 0 = no HTTP response (timeout, refused, DNS...). */
public record CheckResult(int httpCode, long responseMs, String error, boolean up) {
}
