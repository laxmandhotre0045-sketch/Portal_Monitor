# Portal Uptime Monitor — Java version (backend only)

A Java 17+ app that checks each portal's health URL every 60 seconds. It checks all portals in parallel.
After 3 failed checks in a row (not HTTP 200, a timeout, a refused connection, or a DNS failure), it sends one **DOWN** email.
When the portal answers 200 again, it sends one **RECOVERED** email with the total downtime.
It sends no repeat emails while a portal stays down.

> **Hosting note:** Hostinger *shared / web / cloud* hosting runs PHP only and **cannot run Java**.
> Use a **Hostinger VPS** (any KVM plan is plenty; the app uses about 60–100 MB RAM).

## What's in here

| Path | Purpose |
|---|---|
| `portal-monitor.jar` | Ready-to-run jar (all libraries inside). Built and tested with Java 17 target |
| `application.properties` | Settings. **Edit before running** |
| `database.sql` | Creates tables `portals`, `check_logs`, `alert_logs` |
| `deploy/portal-monitor.service` | systemd service so it runs 24/7 and restarts itself |
| `pom.xml`, `src/` | Source code. Rebuild with `mvn package` → `target/portal-monitor.jar` |

### Source layout (`src/main/java/portalmonitor/`)

| Class | Role |
|---|---|
| `App` | Entry point, command-line options, scheduler |
| `Config` | Loads `application.properties` |
| `Database` | All SQL (JDBC) |
| `HealthChecker` | Parallel HTTP checks (Java built-in `HttpClient`) |
| `MonitorService` | UP/DOWN state logic and when to send email |
| `EmailService` | SMTP sending (Jakarta Mail) |
| `EmailTemplates` | DOWN / RECOVERED email content |
| `Portal`, `CheckResult`, `Log` | Data records and logging |

## Database — the `portals` table

| Column | You set | Notes |
|---|---|---|
| `portal_name` | ✅ | Portal number or name, e.g. `Portal-01` |
| `notify_email` | optional | Defaults to `laxmandhotre0045@gmail.com`. Several addresses can be comma-separated |
| `health_url` | ✅ | e.g. `http://IP:8080/actuator/health` |
| `is_active` | optional | `1` = monitor, `0` = pause |

The script fills in the other columns (status, fail count, last code, response time, and so on).

```sql
INSERT INTO portals (portal_name, health_url) VALUES
('Portal-01', 'http://IP:8080/actuator/health'),   -- Spring Boot
('Portal-02', 'http://IP:5000/health'),            -- Python
('Portal-03', 'http://IP:3000/health');            -- Node
```

## Deploy on a Hostinger VPS (Ubuntu)

```bash
# 1. Java + MySQL
sudo apt update
sudo apt install -y openjdk-17-jre-headless mysql-server

# 2. Database and user
sudo mysql -e "CREATE DATABASE portal_monitor;
  CREATE USER 'monitor'@'localhost' IDENTIFIED BY 'STRONG_PASSWORD';
  GRANT ALL ON portal_monitor.* TO 'monitor'@'localhost';"
sudo mysql portal_monitor < database.sql

# 3. App folder + a system user to run it
sudo useradd -r -s /usr/sbin/nologin monitor
sudo mkdir -p /opt/portal-monitor
sudo cp portal-monitor.jar application.properties /opt/portal-monitor/
sudo nano /opt/portal-monitor/application.properties     # set db.password, smtp.user/password/from
sudo chown -R monitor:monitor /opt/portal-monitor
sudo chmod 600 /opt/portal-monitor/application.properties   # it contains passwords

# 4. Test email (check Gmail Spam the first time)
cd /opt/portal-monitor
sudo -u monitor java -jar portal-monitor.jar --test-email laxmandhotre0045@gmail.com

# 5. One test cycle
sudo -u monitor java -jar portal-monitor.jar --once

# 6. Run 24/7 as a service
sudo cp deploy/portal-monitor.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now portal-monitor

# Logs
journalctl -u portal-monitor -f
```

If you'd rather use an existing Hostinger MySQL database instead of installing MySQL on the VPS,
point `db.url` at that host. The database must allow remote connections from the VPS IP (hPanel → Remote MySQL).

## Command-line options

```
java -jar portal-monitor.jar                          # run forever (service mode)
java -jar portal-monitor.jar --once                   # one check cycle, then exit (for cron)
java -jar portal-monitor.jar --test-email you@x.com   # send a test email
java -jar portal-monitor.jar --config /path/app.properties
```

## Health endpoints on the portals

| Stack | How |
|---|---|
| Spring Boot | Add `spring-boot-starter-actuator` and set `management.endpoints.web.exposure.include=health`, giving `/actuator/health` |
| Python | Add a `/health` route that returns 200 (Flask / FastAPI / Django) |
| Node (Express) | `app.get('/health', (req,res) => res.status(200).json({status:'UP'}))` |

Each portal's port must be reachable from the VPS: open it in Windows Firewall and forward it on the router or in the cloud firewall.
If the `last_error` column shows `Couldn't connect to server`, it's usually a firewall or port-forwarding problem.

## Rebuilding from source

```bash
mvn package            # needs Maven + internet (pulls mariadb-java-client and angus-mail)
# -> target/portal-monitor.jar
```
The included prebuilt jar uses mariadb-java-client 2.7.6 and Jakarta Mail 2.0.0. It was tested end to end.
`pom.xml` pulls newer versions of the same libraries, and the code uses only the standard JDBC and Jakarta Mail APIs, so it builds against either.
The MariaDB driver works with MySQL servers too.
