-- =====================================================================
--  Portal Uptime Monitor - Database schema (MySQL / MariaDB)
--  Import this in Hostinger -> Databases -> phpMyAdmin -> Import
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1) portals : one row per deployment you want to monitor
--    YOU fill:  portal_name, notify_email, health_url  (and is_active)
--    SCRIPT fills everything else automatically.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS portals (
    id                 INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    -- ===== Fields you manage =====
    portal_name        VARCHAR(100)  NOT NULL COMMENT 'Portal number or name, e.g. "Portal-01" or "MCSA Backend"',
    notify_email       VARCHAR(500)  NOT NULL DEFAULT 'laxmandhotre0045@gmail.com' COMMENT 'Who gets the alert. Multiple allowed, comma-separated',
    health_url         VARCHAR(500)  NOT NULL COMMENT 'Full health-check URL, e.g. http://1.2.3.4:8080/actuator/health',
    is_active          TINYINT(1)    NOT NULL DEFAULT 1 COMMENT '1 = monitor, 0 = pause monitoring',

    -- ===== Fields the script manages (do not edit by hand) =====
    status             ENUM('UNKNOWN','UP','DOWN') NOT NULL DEFAULT 'UNKNOWN',
    fail_count         INT UNSIGNED  NOT NULL DEFAULT 0   COMMENT 'Consecutive failed checks',
    fail_since         DATETIME      NULL                 COMMENT 'Time of first failure in the current failure streak',
    last_http_code     INT           NULL,
    last_response_ms   INT           NULL,
    last_error         VARCHAR(255)  NULL,
    last_checked       DATETIME      NULL,
    last_status_change DATETIME      NULL,
    created_at         DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,

    UNIQUE KEY uq_portal_name (portal_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 2) check_logs : history of every health check (auto-cleaned after N days)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS check_logs (
    id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    portal_id    INT UNSIGNED NOT NULL,
    http_code    INT          NULL COMMENT '0 = no response (timeout / refused / DNS)',
    response_ms  INT          NULL,
    is_up        TINYINT(1)   NOT NULL,
    error        VARCHAR(255) NULL,
    checked_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_portal_time (portal_id, checked_at),
    KEY idx_checked_at  (checked_at),
    CONSTRAINT fk_logs_portal FOREIGN KEY (portal_id) REFERENCES portals(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 3) alert_logs : every email the system tried to send (and whether it worked)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS alert_logs (
    id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    portal_id   INT UNSIGNED NOT NULL,
    alert_type  ENUM('DOWN','RECOVERED') NOT NULL,
    sent_to     VARCHAR(500) NOT NULL,
    success     TINYINT(1)   NOT NULL,
    error       VARCHAR(500) NULL,
    sent_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_portal_sent (portal_id, sent_at),
    CONSTRAINT fk_alerts_portal FOREIGN KEY (portal_id) REFERENCES portals(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- =====================================================================
--  ADD YOUR PORTALS  (edit and run in phpMyAdmin -> SQL tab)
-- =====================================================================
-- notify_email defaults to laxmandhotre0045@gmail.com, so you can leave it out:
-- INSERT INTO portals (portal_name, health_url) VALUES
-- ('Portal-01', 'http://203.0.113.10:8080/actuator/health'),   -- Spring Boot
-- ('Portal-02', 'http://203.0.113.10:5000/health'),            -- Python
-- ('Portal-03', 'http://203.0.113.11:3000/health');            -- Node
--
-- Or give a portal its own / extra recipients:
-- INSERT INTO portals (portal_name, notify_email, health_url) VALUES
-- ('Portal-04', 'laxmandhotre0045@gmail.com, other@yourdomain.com', 'http://203.0.113.12:8080/actuator/health');

-- Change who gets alerts:
-- UPDATE portals SET notify_email = 'new@yourdomain.com' WHERE portal_name = 'Portal-01';

-- Pause / resume monitoring of a portal:
-- UPDATE portals SET is_active = 0 WHERE portal_name = 'Portal-03';

-- Quick status view:
-- SELECT portal_name, status, last_http_code, last_response_ms, last_checked, last_error FROM portals ORDER BY portal_name;
